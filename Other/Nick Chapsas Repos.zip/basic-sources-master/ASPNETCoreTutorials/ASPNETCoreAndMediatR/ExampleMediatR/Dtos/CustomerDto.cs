using System;

namespace ExampleMediatR.Dtos
{
    public class CustomerDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}