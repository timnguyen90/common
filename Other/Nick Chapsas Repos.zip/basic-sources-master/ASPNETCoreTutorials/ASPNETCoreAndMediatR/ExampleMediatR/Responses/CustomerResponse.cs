using System;

namespace ExampleMediatR.Responses
{
    public class CustomerResponse
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}