﻿using System.Linq;
using System.Threading.Tasks;
using AspNetCoreRateLimit;
using Microsoft.AspNetCore.Http;

namespace ApiRateLimiting.RateLimiting
{
    public class CustomClientResolveContributor : IClientResolveContributor
    {
        public Task<string> ResolveClientAsync(HttpContext httpContext)
        {
            var nickHeaderValue = string.Empty;
            if (httpContext.Request.Headers.TryGetValue("Nick-Header", out var values))
            {
                nickHeaderValue = values.First();
            }

            return Task.FromResult(nickHeaderValue);
        }
    }
}
