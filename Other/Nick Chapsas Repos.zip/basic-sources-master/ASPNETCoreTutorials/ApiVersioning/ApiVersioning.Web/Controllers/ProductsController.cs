using System;
using ApiVersioning.Web.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace ApiVersioning.Web.Controllers
{
    [ApiController]
    [Route("api/products")]
    //[ApiVersion("1.0", Deprecated = true)]
    //[ApiVersion("2.0")]
    public class ProductsController : ControllerBase
    {
        [HttpGet("{productId}")]
        public IActionResult GetProductV1([FromRoute] Guid productId)
        {
            var product = new ProductResponseV1
            {
                Id = productId,
                Name = "JetBrains Rider"
            };
            return Ok(product);
        }

        [HttpGet("{productId}")]
        //[MapToApiVersion("2.0")]
        public IActionResult GetProductV2([FromRoute] Guid productId)
        {
            var product = new ProductResponseV2
            {
                Id = productId,
                ProductName = "JetBrains Rider"
            };
            return Ok(product);
        }
    }
}
