using System.Threading;
using System.Threading.Tasks;
using CancellationTutorial.Api.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace CancellationTutorial.Api.Controllers
{
    [ApiController]
    public class ExampleController : ControllerBase
    {
        private readonly IExampleRepository _exampleRepository;

        public ExampleController(IExampleRepository exampleRepository)
        {
            _exampleRepository = exampleRepository;
        }

        [HttpGet("")]
        public async Task<IActionResult> UnderPerformingQuery(CancellationToken token)
        {
            var result = await _exampleRepository.GetSomeNumberAsync(token);
            return Ok(result);
        }
    }
}
