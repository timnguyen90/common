using System.Data;
using System.Threading.Tasks;

namespace CancellationTutorial.Api.Data
{
    public interface IDbConnectionFactory
    {
        Task<IDbConnection> CreateConnectionAsync();
    }
}
