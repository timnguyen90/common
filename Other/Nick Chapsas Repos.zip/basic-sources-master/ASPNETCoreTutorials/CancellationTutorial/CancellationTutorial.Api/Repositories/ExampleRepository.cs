using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;
using CancellationTutorial.Api.Data;
using Dapper;
using Microsoft.Extensions.Logging;

namespace CancellationTutorial.Api.Repositories
{
    public class ExampleRepository : IExampleRepository
    {
        private readonly IDbConnectionFactory _dbConnectionFactory;
        private readonly ILogger<ExampleRepository> _logger;

        public ExampleRepository(IDbConnectionFactory dbConnectionFactory, ILogger<ExampleRepository> logger)
        {
            _dbConnectionFactory = dbConnectionFactory;
            _logger = logger;
        }

        public async Task<int> GetSomeNumberAsync(CancellationToken token)
        {
            using var connection = await _dbConnectionFactory.CreateConnectionAsync();
            _logger.LogInformation("Calling the database to get the results back. Might take a while.");

            var commandDefinition =
                new CommandDefinition(@"WITH RECURSIVE r(i) AS (VALUES(0) UNION ALL SELECT i FROM r LIMIT 30000000)
                                        SELECT i FROM r WHERE i = 1;", cancellationToken:token);

            try
            {
                var firstResult = await connection.QueryFirstOrDefaultAsync<int>(commandDefinition);
                _logger.LogInformation("First result returned from the database. It was: {0}", firstResult);

                var secondResult = await connection.QueryFirstOrDefaultAsync<int>(commandDefinition);
                _logger.LogInformation("Second result returned from the database. It was: {0}", secondResult);
                return firstResult + secondResult;
            }
            catch (TaskCanceledException exception)
            {
                Console.WriteLine("Operation was cancelled. Saved resources yeee");
            }

            return 0;
        }
    }
}
