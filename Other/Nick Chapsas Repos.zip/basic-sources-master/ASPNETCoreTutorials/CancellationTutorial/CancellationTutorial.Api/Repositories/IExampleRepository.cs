using System.Threading;
using System.Threading.Tasks;

namespace CancellationTutorial.Api.Repositories
{
    public interface IExampleRepository
    {
        Task<int> GetSomeNumberAsync(CancellationToken token);
    }
}
