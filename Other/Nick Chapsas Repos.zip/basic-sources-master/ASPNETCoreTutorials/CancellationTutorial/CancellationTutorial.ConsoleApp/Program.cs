﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace CancellationTutorial.ConsoleApp
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var cancellationTokenSource = new CancellationTokenSource();
            await ExampleWithLoop(cancellationTokenSource);
        }

        public static async Task ExampleWithLoop(CancellationTokenSource cancellationTokenSource)
        {
            Task.Run(() =>
            {
                var key = Console.ReadKey();
                if (key.Key == ConsoleKey.C)
                {
                    cancellationTokenSource.Cancel();
                    Console.WriteLine("Cancelled the task");
                }
            });

            try
            {
                while (true)
                {
                    cancellationTokenSource.Token.ThrowIfCancellationRequested();
                    Console.WriteLine("Doing some work for 5 seconds");
                    await Task.Delay(5000);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            Console.WriteLine("Token was cancelled and we exited the loop");
            cancellationTokenSource.Dispose();
        }
    }
}
