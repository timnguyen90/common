using System;

namespace ExampleMessageConsumer.Contracts
{
    public class CustomerCreated : IConsumableMessage
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public string FullName { get; set; }

        public string Email { get; set; }

        public DateTime DateOfBirth { get; set; }
    }
}
