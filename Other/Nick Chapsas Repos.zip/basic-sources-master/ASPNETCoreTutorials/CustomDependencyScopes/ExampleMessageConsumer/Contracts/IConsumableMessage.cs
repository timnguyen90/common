namespace ExampleMessageConsumer.Contracts
{
    public interface IConsumableMessage
    {
        
    }
}