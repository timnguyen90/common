using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;

namespace ExampleMessageConsumer
{
    public interface IMessageHandler
    {
        Task<bool> HandleMessageAsync(ProcessMessageEventArgs message);
    }
}
