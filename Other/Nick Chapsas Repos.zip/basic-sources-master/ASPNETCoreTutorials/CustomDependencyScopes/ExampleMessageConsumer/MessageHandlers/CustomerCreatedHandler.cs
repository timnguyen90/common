using System;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using ExampleMessageConsumer.Contracts;
using ExampleMessageConsumer.Services;

namespace ExampleMessageConsumer.MessageHandlers
{
    public class CustomerCreatedHandler : IMessageHandler
    {
        private readonly CustomerService _customerService;

        public CustomerCreatedHandler(CustomerService customerService)
        {
            _customerService = customerService;
        }

        public Task<bool> HandleMessageAsync(ProcessMessageEventArgs messageEventArgs)
        {
            var message = JsonSerializer.Deserialize<CustomerCreated>(messageEventArgs.Message.Body.ToString());
            Console.WriteLine($"Received CustomerCreated message with body: {JsonSerializer.Serialize(messageEventArgs.Message.Body.ToString())}");
            _customerService.AddCustomer(new {});
            return Task.FromResult(true);
        }
    }
}
