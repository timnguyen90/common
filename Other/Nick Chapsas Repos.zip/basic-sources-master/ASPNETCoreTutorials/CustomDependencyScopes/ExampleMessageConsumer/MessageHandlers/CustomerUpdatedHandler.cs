using System;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using ExampleMessageConsumer.Contracts;
using ExampleMessageConsumer.Services;

namespace ExampleMessageConsumer.MessageHandlers
{
    public class CustomerUpdatedHandler : IMessageHandler
    {
        private readonly CustomerService _customerService;

        public CustomerUpdatedHandler(CustomerService customerService)
        {
            _customerService = customerService;
        }

        public Task<bool> HandleMessageAsync(ProcessMessageEventArgs messageArgs)
        {
            var message = JsonSerializer.Deserialize<CustomerUpdated>(messageArgs.Message.Body.ToString());
            Console.WriteLine($"Received CustomerUpdated message with body: {JsonSerializer.Serialize(messageArgs.Message.Body.ToString())}");
            _customerService.AddCustomer(new {});
            return Task.FromResult(true);
        }
    }
}
