using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Azure.Messaging.ServiceBus;
using ExampleMessageConsumer.Contracts;
using ExampleMessageConsumer.MessageHandlers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ExampleMessageConsumer
{
    public class MessageHandlingDispatcher : BackgroundService
    {
        // You can also do it with reflection
        // private static readonly IDictionary<string, Type> ConsumableMessageTypes = typeof(IConsumableMessage).Assembly.ExportedTypes
        //     .Where(x => !x.IsAbstract && !x.IsInterface && typeof(IConsumableMessage).IsAssignableFrom(x))
        //     .ToDictionary(type => type.Name, type => type);
        //
        // private static readonly IDictionary<Type, Type> MessageHandlers = typeof(IMessageHandler).Assembly.ExportedTypes
        //     .Where(x => !x.IsAbstract && !x.IsInterface && typeof(IMessageHandler<>).IsAssignableFrom(x))
        //     .ToDictionary(type => type.GetInterfaces().Single(x => x.IsGenericType && x.GetGenericTypeDefinition() == typeof(IMessageHandler<>)).GenericTypeArguments[0], type => type);

        private static readonly IDictionary<string, Type> ConsumableMessageTypes = new Dictionary<string, Type>
        {
            {nameof(CustomerCreated), typeof(CustomerCreated)},
            {nameof(CustomerUpdated), typeof(CustomerUpdated)}
        };

        private static readonly IDictionary<Type, Type> MessageHandlers = new Dictionary<Type, Type>
        {
            {typeof(CustomerCreated), typeof(CustomerCreatedHandler)},
            {typeof(CustomerUpdated), typeof(CustomerUpdatedHandler)}
        };

        private readonly ServiceBusProcessor _serviceBusProcessor;
        private readonly IServiceProvider _serviceProvider;

        public MessageHandlingDispatcher(ServiceBusProcessor serviceBusProcessor, IServiceProvider serviceProvider)
        {
            _serviceBusProcessor = serviceBusProcessor;
            _serviceProvider = serviceProvider;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _serviceBusProcessor.ProcessMessageAsync += MessageHandler;
            _serviceBusProcessor.ProcessErrorAsync += ErrorHandler;
            return _serviceBusProcessor.StartProcessingAsync(stoppingToken);
        }

        private async Task MessageHandler(ProcessMessageEventArgs args)
        {
            if (!args.Message.ApplicationProperties.TryGetValue("MessageType", out var messageTypeName))
            {
                Console.WriteLine("No MessageType message property found. Skipping.");
                await args.CompleteMessageAsync(args.Message);
                return;
            }

            if (!ConsumableMessageTypes.TryGetValue(messageTypeName.ToString() ?? string.Empty, out var messageType))
            {
                Console.WriteLine($"Message of MessageType {messageTypeName} is not consumable. Skipping.");
                await args.CompleteMessageAsync(args.Message);
                return;
            }

            // scope starts here
            using (var serviceScope = _serviceProvider.CreateScope())
            {
                var handler = (IMessageHandler)ActivatorUtilities.CreateInstance(serviceScope.ServiceProvider, MessageHandlers[messageType]);
                var complete = await handler!.HandleMessageAsync(args);

                if (complete)
                {
                    await args.CompleteMessageAsync(args.Message);
                    return;
                }

                await args.AbandonMessageAsync(args.Message);
            }
            // scope ends here
        }

        private static Task ErrorHandler(ProcessErrorEventArgs args)
        {
            Console.WriteLine(args.Exception.ToString());
            return Task.CompletedTask;
        }
    }
}
