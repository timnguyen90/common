using ExampleMessageConsumer.Services;

namespace ExampleMessageConsumer.Repositories
{
    public class CustomerRepository
    {
        private readonly CustomLogger _logger;

        public CustomerRepository(CustomLogger logger)
        {
            _logger = logger;
        }

        public void AddCustomer(object customer)
        {
            _logger.PrintRequestId();
        }
    }
}
