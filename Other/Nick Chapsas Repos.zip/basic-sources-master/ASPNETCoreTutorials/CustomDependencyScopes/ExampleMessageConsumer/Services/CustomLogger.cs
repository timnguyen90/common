using System;

namespace ExampleMessageConsumer.Services
{
    public class CustomLogger
    {
        public Guid RequestId { get; set; } = Guid.NewGuid();

        public void PrintRequestId()
        {
            Console.WriteLine(RequestId);
        }
    }
}
