using ExampleMessageConsumer.Repositories;

namespace ExampleMessageConsumer.Services
{
    public class CustomerService
    {
        private readonly CustomerRepository _customerRepository;
        private readonly CustomLogger _logger;

        public CustomerService(CustomerRepository customerRepository, CustomLogger logger)
        {
            _customerRepository = customerRepository;
            _logger = logger;
        }

        public void AddCustomer(object customer)
        {
            _logger.PrintRequestId();
            _customerRepository.AddCustomer(customer);
        }
    }
}
