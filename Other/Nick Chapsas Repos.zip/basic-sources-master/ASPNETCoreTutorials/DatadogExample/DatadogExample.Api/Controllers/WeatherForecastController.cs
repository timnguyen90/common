﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DatadogExample.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace DatadogExample.Api.Controllers
{
    [ApiController]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IWeatherService _weatherService;

        public WeatherForecastController(IWeatherService weatherService)
        {
            _weatherService = weatherService;
        }

        [HttpGet("weatherforecast")]
        public IActionResult GetWeatherForecast()
        {
            var weather = _weatherService.GetWeatherForecast();
            return Ok(weather);
        }
    }
}
