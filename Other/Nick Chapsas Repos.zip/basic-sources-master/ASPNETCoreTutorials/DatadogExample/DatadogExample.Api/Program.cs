using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using Serilog.Sinks.Datadog.Logs;

namespace DatadogExample.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .UseSerilog((context, provider, loggerConfig) =>
                {
                    var datadogLogConfig = new DatadogConfiguration(
                        url: "https://http-intake.logs.datadoghq.eu",
                        port: 443,
                        useSSL: true
                    );
                    loggerConfig
                        .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                        .MinimumLevel.Override("Microsoft.Hosting.Lifetime", LogEventLevel.Information)
                        .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
                        .Enrich.FromLogContext()
                        .WriteTo.Console()
                        .WriteTo.DatadogLogs(
                            apiKey: "51ddb0708a08c407bc66543670185289",
                            source: "nick-yt",
                            service: "datadog-example-api",
                            host: Dns.GetHostName(),
                            tags: new []{$"env:{context.HostingEnvironment.EnvironmentName}"},
                            configuration: datadogLogConfig);
                })
                .ConfigureWebHostDefaults(webBuilder => { webBuilder.UseStartup<Startup>(); });
        }
    }
}
