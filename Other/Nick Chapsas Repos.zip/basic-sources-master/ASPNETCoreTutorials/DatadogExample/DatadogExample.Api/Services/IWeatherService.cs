using System.Collections.Generic;

namespace DatadogExample.Api.Services
{
    public interface IWeatherService
    {
        IEnumerable<WeatherForecast> GetWeatherForecast();
    }
}
