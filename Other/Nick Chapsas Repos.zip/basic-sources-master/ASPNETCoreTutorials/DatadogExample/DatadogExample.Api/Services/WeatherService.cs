using System;
using System.Collections.Generic;
using System.Linq;
using StatsdClient;

namespace DatadogExample.Api.Services
{
    public class WeatherService : IWeatherService
    {
        private static readonly string[] Summaries = {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly IDogStatsd _dogStatsd;

        public WeatherService(IDogStatsd dogStatsd)
        {
            _dogStatsd = dogStatsd;
        }

        public IEnumerable<WeatherForecast> GetWeatherForecast()
        {
            _dogStatsd.Increment("nick_metric.mynewcounter");
            var rng = new Random();

            if (rng.Next(5, 10) > 7)
            {
                throw new Exception("Oops");
            }

            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
                {
                    Date = DateTime.Now.AddDays(index),
                    TemperatureC = rng.Next(-20, 55),
                    Summary = Summaries[rng.Next(Summaries.Length)]
                })
                .ToArray();
        }
    }
}
