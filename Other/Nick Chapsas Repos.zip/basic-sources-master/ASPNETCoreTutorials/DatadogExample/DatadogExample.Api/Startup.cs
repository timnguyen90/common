using DatadogExample.Api.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Events;
using StatsdClient;

namespace DatadogExample.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo {Title = "DatadogExample.Api", Version = "v1"});
            });

            services.AddSingleton<IWeatherService, WeatherService>();

            services.AddSingleton<IDogStatsd>(provider =>
            {
                var dogStatsD = new DogStatsdService();
                var statsDConfig = new StatsdConfig
                {
                    ServiceName = "datadog-example-api",
                    StatsdServerName = "127.0.0.1",
                    ConstantTags = new []{"source:nick-yt"},
                    StatsdPort = 8125,
                    Environment = provider.GetRequiredService<IWebHostEnvironment>().EnvironmentName
                };

                dogStatsD.Configure(statsDConfig);
                return dogStatsD;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "DatadogExample.Api v1"));
            }

            app.UseSerilogRequestLogging();

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints => { endpoints.MapControllers(); });
        }
    }
}
