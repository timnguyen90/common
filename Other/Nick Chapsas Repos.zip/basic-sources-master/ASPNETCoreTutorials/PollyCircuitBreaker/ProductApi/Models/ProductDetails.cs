using System;

namespace ProductApi.Models
{
    public class ProductDetails
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}
