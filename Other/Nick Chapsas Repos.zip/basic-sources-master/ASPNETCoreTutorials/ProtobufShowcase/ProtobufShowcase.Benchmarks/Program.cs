﻿using BenchmarkDotNet.Running;

namespace ProtobufShowcase.Benchmarks
{
    class Program
    {
        static void Main(string[] args)
        {
            BenchmarkRunner.Run<SerializationBenchmark>();
        }
    }
}
