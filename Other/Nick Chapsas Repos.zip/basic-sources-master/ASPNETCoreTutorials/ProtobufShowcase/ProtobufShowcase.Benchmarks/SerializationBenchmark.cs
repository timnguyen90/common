using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using BenchmarkDotNet.Attributes;
using ProtoBuf;
using ProtobufShowcase.Data;
using ProtobufShowcase.Services;

namespace ProtobufShowcase.Benchmarks
{
    public class SerializationBenchmark
    {
        private static readonly WeatherForecastService WeatherForecastService = new WeatherForecastService();

        [Benchmark]
        public async Task<List<WeatherForecast>> JsonSerialize() =>
            JsonSerializer.Deserialize<List<WeatherForecast>>(JsonSerializer.Serialize(await WeatherForecastService.GetWeatherForecastForDay(DateTime.UtcNow.Date)));

        [Benchmark]
        public async Task<List<WeatherForecast>> ProtobufSerialize() =>
            Serializer.Deserialize<List<WeatherForecast>>(ProtoSerialize(await WeatherForecastService.GetWeatherForecastForDay(DateTime.UtcNow.Date)));

        private static Stream ProtoSerialize<T>(T record) where T : class
        {
            var stream = new MemoryStream();
            Serializer.Serialize(stream, record);
            return stream;
        }
    }
}
