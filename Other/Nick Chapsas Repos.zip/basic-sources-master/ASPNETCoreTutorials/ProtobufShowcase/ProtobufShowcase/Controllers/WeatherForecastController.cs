﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProtobufShowcase.Services;

namespace ProtobufShowcase.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IWeatherForecastService _weatherForecastService;

        public WeatherForecastController(IWeatherForecastService weatherForecastService)
        {
            _weatherForecastService = weatherForecastService;
        }

        [HttpGet]
        public async Task<IActionResult> GetWeatherForecast([FromQuery(Name = "date")] DateTime? dateTime = null)
        {
            return Ok(await _weatherForecastService.GetWeatherForecastForDay(dateTime ?? DateTime.UtcNow.Date));
        }
    }
}
