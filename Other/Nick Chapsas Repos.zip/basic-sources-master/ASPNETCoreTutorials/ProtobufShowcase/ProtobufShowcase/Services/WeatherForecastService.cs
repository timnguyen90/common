using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProtobufShowcase.Data;

namespace ProtobufShowcase.Services
{
    public class WeatherForecastService : IWeatherForecastService
    {
        private static readonly Random Rng = new Random(6666);
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        public async Task<IEnumerable<WeatherForecast>> GetWeatherForecastForDay(DateTime dateTime)
        {

            return await Task.FromResult(Enumerable.Range(1, 10).Select(index => new WeatherForecast
                {
                    Date = DateTime.Now.AddDays(index),
                    TemperatureC = Rng.Next(-20, 55),
                    Summary = Summaries[Rng.Next(Summaries.Length)]
                })
                .ToArray());
        }
    }
}
