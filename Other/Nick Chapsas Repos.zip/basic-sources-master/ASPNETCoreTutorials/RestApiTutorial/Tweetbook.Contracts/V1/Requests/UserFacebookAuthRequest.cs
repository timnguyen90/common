namespace Tweetbook.Contracts.V1.Requests
{
    public class UserFacebookAuthRequest
    {
        public string AccessToken { get; set; }
    }
}