namespace Tweetbook.Contracts.V1.Responses
{
    public class TagResponse
    {
        public string Name { get; set; }
    }
}