namespace Tweetbook.Domain
{
    public class GetAllPostsFilter
    {
        public string UserId { get; set; }
    }
}