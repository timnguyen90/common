﻿namespace ScrutorExample.Services
{
    public interface IMetricService
    {
        
    }

    public class MetricService : IMetricService
    {
        
    }
}