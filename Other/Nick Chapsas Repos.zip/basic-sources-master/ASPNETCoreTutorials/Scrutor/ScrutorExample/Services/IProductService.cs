﻿namespace ScrutorExample.Services
{
    public interface IProductService
    {
        
    }

    public class ProductService : IProductService
    {
        
    }
}