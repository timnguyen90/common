﻿using System.Text.Json.Serialization;

namespace SpeedUpAsync.Contracts
{
    public class GitHubUser
    {
        [JsonPropertyName("followers")]
        public int Followers { get; set; }
    }
}
