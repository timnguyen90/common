﻿using System.Text.Json.Serialization;

namespace SpeedUpAsync.Contracts
{
    public class TwitterUser
    {
        [JsonPropertyName("followers")]
        public int Followers { get; set; }
    }
}
