﻿using System.Text.Json.Serialization;

namespace SpeedUpAsync.Contracts
{
    public class YoutubeUser
    {
        [JsonPropertyName("subscribers")]
        public int Subscribers { get; set; }
    }
}
