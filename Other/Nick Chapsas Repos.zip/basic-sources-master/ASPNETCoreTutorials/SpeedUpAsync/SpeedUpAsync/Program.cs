﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using SpeedUpAsync.Contracts;

namespace SpeedUpAsync
{
    public record UserProfile(string FullName, int YoutubeSubscribers, int GitHubFollowers, int TwitterFollowers);

    class Program
    {
        static async Task Main(string[] args)
        {
            var httpClient = new HttpClient();

            var stopwatch = Stopwatch.StartNew();

            var youtubeSubscribersTask = GetYoutubeSubscribers(httpClient);
            var twitterFollowersTask = GetTwitterFollowers(httpClient);
            var githubFollowersTask = GetGithubFollowers(httpClient);

            await TaskExt.WhenAll(youtubeSubscribersTask, twitterFollowersTask, githubFollowersTask);

            var youtubeSubscribers = await youtubeSubscribersTask;
            var twitterFollowers = await twitterFollowersTask;
            var githubFollowers = await githubFollowersTask;

            Console.WriteLine($"Done in: {stopwatch.ElapsedMilliseconds}ms");

            var userProfile = new UserProfile("Nick Chapsas", twitterFollowers, youtubeSubscribers, githubFollowers);
            Console.WriteLine(userProfile.ToString());

            // var taskCompletionSource = new TaskCompletionSource<int>();
            // taskCompletionSource.TrySetException(new Exception[]
            // {
            //     new("This went wrong first"),
            //     new("This went wrong later")
            // });
            //
            // var result = await TaskExt.WhenAll(taskCompletionSource.Task);
        }

        private static async Task<int> GetYoutubeSubscribers(HttpClient httpClient)
        {
            var githubResponse = await httpClient.GetStringAsync($"https://localhost:5001/youtube");
            var youtubeUser = JsonSerializer.Deserialize<YoutubeUser>(githubResponse);
            return youtubeUser!.Subscribers;
        }

        private static async Task<int> GetTwitterFollowers(HttpClient httpClient)
        {
            var twitterResponse = await httpClient.GetStringAsync($"https://localhost:5001/twitter");
            var twitterUser = JsonSerializer.Deserialize<TwitterUser>(twitterResponse);
            return twitterUser!.Followers;
        }

        private static async Task<int> GetGithubFollowers(HttpClient httpClient)
        {
            var githubResponse = await httpClient.GetStringAsync($"https://localhost:5001/github");
            var gitHubUser = JsonSerializer.Deserialize<GitHubUser>(githubResponse);
            return gitHubUser!.Followers;
        }
    }

    public class TaskExt
    {
        public static async Task<IEnumerable<T>> WhenAll<T>(params Task<T>[] tasks)
        {
            var allTasks = Task.WhenAll(tasks);

            try
            {
                return await allTasks;
            }
            catch (Exception)
            {
                //ignore
            }

            throw allTasks.Exception ?? throw new Exception("This can't possibly happen");
        }
    }
}
