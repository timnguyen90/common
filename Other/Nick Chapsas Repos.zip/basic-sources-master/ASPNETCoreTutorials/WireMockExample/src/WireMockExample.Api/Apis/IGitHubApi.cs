using System.Threading.Tasks;
using Refit;

namespace WireMockExample.Api.Apis
{
    [Headers("User-Agent: WireMock Integration Tests")]
    public interface IGitHubApi
    {
        [Get("/users/{username}")]
        Task<GithubUser> GetUserAsync(string userName);
    }
}
