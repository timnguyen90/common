using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WireMockExample.Api.Services;

namespace WireMockExample.Api.Controllers
{
    [ApiController]
    public class ExampleController : ControllerBase
    {
        private readonly IUserService _userService;

        public ExampleController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("users/{userId:Guid}")]
        public async Task<IActionResult> GetUserById([FromRoute]Guid userId)
        {
            var user = await _userService.GetByIdAsync(userId);
            return user is null ? NotFound() : Ok(user);
        }
    }
}
