using System.Data;

namespace WireMockExample.Api.Data
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateDbConnection();
    }
}
