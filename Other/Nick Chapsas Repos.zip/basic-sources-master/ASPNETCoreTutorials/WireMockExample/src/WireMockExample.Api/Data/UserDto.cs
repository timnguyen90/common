using System;

namespace WireMockExample.Api.Data
{
    public class UserDto
    {
        public Guid Id { get; set; }

        public string FullName { get; set; }

        public string GithubUsername { get; set; }
    }
}
