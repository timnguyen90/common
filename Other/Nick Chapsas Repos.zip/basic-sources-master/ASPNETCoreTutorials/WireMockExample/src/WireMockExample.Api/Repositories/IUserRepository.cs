using System;
using System.Threading.Tasks;
using WireMockExample.Api.Data;

namespace WireMockExample.Api.Repositories
{
    public interface IUserRepository
    {
        Task CreateAsync(UserDto user);

        Task<UserDto> GetByIdAsync(Guid userId);

        Task DeleteAsync(Guid userId);
    }
}
