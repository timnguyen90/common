using System;
using System.Threading.Tasks;
using Dapper;
using WireMockExample.Api.Data;

namespace WireMockExample.Api.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly IDbConnectionFactory _dbConnectionFactory;

        public UserRepository(IDbConnectionFactory dbConnectionFactory)
        {
            _dbConnectionFactory = dbConnectionFactory;
        }

        public async Task CreateAsync(UserDto user)
        {
            using var connection = _dbConnectionFactory.CreateDbConnection();
            await connection.ExecuteAsync(
                "insert into users (Id, FullName, GithubUsername) values (@Id, @FullName, @GithubUsername)",
                user
            );
        }

        public async Task<UserDto> GetByIdAsync(Guid userId)
        {
            using var connection = _dbConnectionFactory.CreateDbConnection();
            return await connection.QuerySingleOrDefaultAsync<UserDto>("select * from users where id=@userId", new {userId});
        }

        public async Task DeleteAsync(Guid userId)
        {
            using var connection = _dbConnectionFactory.CreateDbConnection();
            await connection.ExecuteAsync("delete from users where Id=@userId", new {userId});
        }
    }
}
