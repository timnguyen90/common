using System;
using System.Threading.Tasks;
using WireMockExample.Api.Models;

namespace WireMockExample.Api.Services
{
    public interface IUserService
    {
        Task<User> GetByIdAsync(Guid userId);
    }
}
