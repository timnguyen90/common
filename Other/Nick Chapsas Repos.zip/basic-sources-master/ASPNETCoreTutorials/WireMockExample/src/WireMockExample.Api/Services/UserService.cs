using System;
using System.Threading.Tasks;
using WireMockExample.Api.Apis;
using WireMockExample.Api.Models;
using WireMockExample.Api.Repositories;

namespace WireMockExample.Api.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IGitHubApi _gitHubApi;

        public UserService(IUserRepository userRepository, IGitHubApi gitHubApi)
        {
            _userRepository = userRepository;
            _gitHubApi = gitHubApi;
        }

        public async Task<User> GetByIdAsync(Guid userId)
        {
            var user = await _userRepository.GetByIdAsync(userId);

            if (user is null)
            {
                return null;
            }

            var githubUser = await _gitHubApi.GetUserAsync(user.GithubUsername);

            return new User
            {
                Id = user.Id,
                FullName = user.FullName,
                GithubUsername = user.GithubUsername,
                GithubFollowers = githubUser.Followers,
                BlogUrl = githubUser.Blog
            };
        }
    }
}
