﻿using System;
using WireMock.RequestBuilders;
using WireMock.ResponseBuilders;
using WireMock.Server;

namespace WireMockExample.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var wireMockServer = WireMockServer.Start();

            Console.WriteLine($"Server is running at: {wireMockServer.Urls[0]}");

            wireMockServer
                .Given(Request.Create().WithPath("/test").UsingGet())
                .RespondWith(Response.Create().WithBody("Hello from WireMock!!!"));

            Console.ReadKey();
            wireMockServer.Stop();
            wireMockServer.Dispose();
        }
    }
}
