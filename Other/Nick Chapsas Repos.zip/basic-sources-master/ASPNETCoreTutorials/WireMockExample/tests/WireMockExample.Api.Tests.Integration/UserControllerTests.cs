using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http.Json;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using WireMock.RequestBuilders;
using WireMock.ResponseBuilders;
using WireMock.Server;
using WireMockExample.Api.Apis;
using WireMockExample.Api.Data;
using WireMockExample.Api.Models;
using WireMockExample.Api.Repositories;
using Xunit;

namespace WireMockExample.Api.Tests.Integration
{
    public class UserControllerTests : IClassFixture<IntegrationTestAppFactory<Startup>>, IAsyncLifetime
    {
        private readonly IntegrationTestAppFactory<Startup> _factory;
        private readonly List<UserDto> _testUsers = new();
        private readonly Fixture _fixture = new();
        private readonly WireMockServer _wireMockServer;

        public UserControllerTests(IntegrationTestAppFactory<Startup> factory)
        {
            _factory = factory;
            _wireMockServer = _factory.Services.GetRequiredService<WireMockServer>();
        }

        public Task InitializeAsync()
        {
            return Task.CompletedTask;
        }

        [Fact]
        public async Task GetUser_ShouldReturnUser_WhenUserExists()
        {
            // Arrange
            var dataAccess = _factory.Services.GetRequiredService<IUserRepository>();
            var testUser = await SetupTestUserAsync(dataAccess, new UserDto
            {
                Id = Guid.NewGuid(),
                FullName = "Nick Chapsas",
                GithubUsername = "Elfocrash"
            });

            var expectedUser = new User
            {
                Id = testUser.Id,
                FullName = testUser.FullName,
                GithubUsername = testUser.GithubUsername,
                BlogUrl = "https://www.youtube.com/ElfocrashDev",
                GithubFollowers = 420
            };

            var githubUser = _fixture.Build<GithubUser>()
                .With(user => user.Name, testUser.GithubUsername)
                .With(user => user.Blog, expectedUser.BlogUrl)
                .With(user => user.Followers, expectedUser.GithubFollowers)
                .Create();

            _wireMockServer
                .Given(Request.Create().WithPath($"/users/{testUser.GithubUsername}"))
                .RespondWith(
                    Response.Create().WithBodyAsJson(githubUser)
                        .WithStatusCode(HttpStatusCode.OK)
                    );

            var httpClient = _factory.CreateClient();

            // Act
            var response = await httpClient.GetAsync($"/users/{testUser.Id}");

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var responseObject = await response.Content.ReadFromJsonAsync<User>();
            responseObject.Should().BeEquivalentTo(expectedUser);
        }

        [Fact]
        public async Task GetUser_ShouldReturnNotFound_WhenUserDoesntExist()
        {
            // Arrange
            var randomId = Guid.NewGuid();
            var httpClient = _factory.CreateClient();

            // Act
            var response = await httpClient.GetAsync($"/user/{randomId}");

            // Assert
            response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }

        private async Task<UserDto> SetupTestUserAsync(IUserRepository userRepository, UserDto testUser)
        {
            await userRepository.CreateAsync(testUser);
            _testUsers.Add(testUser);
            return testUser;
        }

        async Task IAsyncLifetime.DisposeAsync()
        {
            var userRepository = _factory.Services.GetRequiredService<IUserRepository>();
            foreach (var testUser in _testUsers)
            {
                await userRepository.DeleteAsync(testUser.Id);
            }
        }
    }
}
