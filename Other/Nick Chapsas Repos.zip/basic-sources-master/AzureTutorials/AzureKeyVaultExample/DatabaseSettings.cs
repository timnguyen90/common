namespace AzureKeyVaultExample
{
    public class DatabaseSettings
    {
        public string DatabaseName { get; set; }

        public string DatabaseUrl { get; set; }

        public string DatabaseKey { get; set; }
    }
}