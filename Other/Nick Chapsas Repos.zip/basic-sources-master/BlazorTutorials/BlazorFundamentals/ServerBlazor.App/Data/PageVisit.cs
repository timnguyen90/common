using System;

namespace ServerBlazor.Data
{
    public class PageVisit
    {
        public string Url { get; set; }

        public DateTime DateTime { get; set; }
    }
}