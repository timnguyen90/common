namespace ServerBlazor.Store.Counter
{
    public class IncrementCounterAction
    {
    }
}