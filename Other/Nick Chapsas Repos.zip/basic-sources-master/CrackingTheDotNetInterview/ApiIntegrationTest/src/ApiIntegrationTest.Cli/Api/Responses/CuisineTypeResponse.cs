using System.Text.Json.Serialization;

namespace ApiIntegrationTest.Cli.Api.Responses
{
    public record CuisineTypeResponse
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
    }
}
