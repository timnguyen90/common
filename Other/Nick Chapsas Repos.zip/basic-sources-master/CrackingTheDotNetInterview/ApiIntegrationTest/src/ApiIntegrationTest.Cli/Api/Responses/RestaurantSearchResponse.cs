using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ApiIntegrationTest.Cli.Api.Responses
{
    public record RestaurantSearchResponse
    {
        [JsonPropertyName("restaurants")]
        public IReadOnlyList<RestaurantResponse> Restaurants { get; init; }
    }
}
