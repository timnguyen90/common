using System.Collections.Generic;

namespace ApiIntegrationTest.Cli.Models
{
    public record RestaurantResult
    {
        public string Name { get; init; }

        public double Rating { get; init; }

        public IReadOnlyList<string> CuisineTypes { get; init; }
    }
}
