using System.Collections.Generic;

namespace ApiIntegrationTest.Cli.Models
{
    public record RestaurantSearchError
    {
        public IReadOnlyList<string> ErrorMessages { get; }

        public RestaurantSearchError(IReadOnlyList<string> errorMessages)
        {
            ErrorMessages = errorMessages;
        }
    }
}
