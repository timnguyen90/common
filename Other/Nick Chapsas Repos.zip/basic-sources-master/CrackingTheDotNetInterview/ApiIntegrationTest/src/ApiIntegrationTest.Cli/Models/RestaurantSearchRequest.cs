namespace ApiIntegrationTest.Cli.Models
{
    public record RestaurantSearchRequest
    {
        public RestaurantSearchRequest(string outcode)
        {
            Outcode = outcode;
        }

        public string Outcode { get; }
    }
}
