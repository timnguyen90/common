namespace ApiIntegrationTest.Cli.Output
{
    public interface IConsoleWriter
    {
        void WriteLine(string text);
    }
}
