using System.Text.Json;
using System.Threading.Tasks;
using ApiIntegrationTest.Cli.Models;
using ApiIntegrationTest.Cli.Output;
using ApiIntegrationTest.Cli.Services;
using CommandLine;
using OneOf;

namespace ApiIntegrationTest.Cli
{
    public class RestaurantSearchApplication
    {
        private readonly IConsoleWriter _consoleWriter;
        private readonly IRestaurantSearchService _restaurantSearchService;

        public RestaurantSearchApplication(
            IConsoleWriter consoleWriter,
            IRestaurantSearchService restaurantSearchService)
        {
            _consoleWriter = consoleWriter;
            _restaurantSearchService = restaurantSearchService;
        }

        public async Task RunAsync(string[] args)
        {
            await Parser.Default
                .ParseArguments<RestaurantSearchApplicationOption>(args)
                .WithParsedAsync(async option =>
                {
                    var searchRequest = new RestaurantSearchRequest(option.Outcode);
                    var result = await _restaurantSearchService.SearchByOutcodeAsync(searchRequest);
                    HandleSearchResult(result);
                });
        }

        private void HandleSearchResult(OneOf<RestaurantSearchResult, RestaurantSearchError> result)
        {
            result.Switch(searchResult =>
            {
                var formattedTextResult = JsonSerializer.Serialize(searchResult, new JsonSerializerOptions
                {
                    WriteIndented = true
                });
                _consoleWriter.WriteLine(formattedTextResult);
            },
            error =>
            {
                var formattedErrors = string.Join(", ", error.ErrorMessages);
                _consoleWriter.WriteLine(formattedErrors);
            });
        }
    }
}
