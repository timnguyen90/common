using System.Linq;
using System.Threading.Tasks;
using ApiIntegrationTest.Cli.Api;
using ApiIntegrationTest.Cli.Mapping;
using ApiIntegrationTest.Cli.Models;
using FluentValidation;
using OneOf;

namespace ApiIntegrationTest.Cli.Services
{
    public class RestaurantSearchService : IRestaurantSearchService
    {
        private readonly IRestaurantApi _restaurantApi;
        private readonly IValidator<RestaurantSearchRequest> _validator;

        public RestaurantSearchService(
            IRestaurantApi restaurantApi,
            IValidator<RestaurantSearchRequest> validator)
        {
            _restaurantApi = restaurantApi;
            _validator = validator;
        }

        public async Task<OneOf<RestaurantSearchResult, RestaurantSearchError>> SearchByOutcodeAsync(
            RestaurantSearchRequest request)
        {
            var validationResult = _validator.Validate(request);
            if (!validationResult.IsValid)
            {
                var errorMessages = validationResult.Errors.Select(x => x.ErrorMessage).ToList();
                return new RestaurantSearchError(errorMessages);
            }

            var response = await _restaurantApi.SearchByPostcodeAsync(request.Outcode);
            return new RestaurantSearchResult
            {
                Restaurants = response.Restaurants.Select(x => x.ToRestaurantResult()).ToList()
            };
        }
    }
}
