using ApiIntegrationTest.Cli.Models;
using FluentValidation;

namespace ApiIntegrationTest.Cli.Validators
{
    public class RestaurantSearchRequestValidator : AbstractValidator<RestaurantSearchRequest>
    {
        public RestaurantSearchRequestValidator()
        {
            RuleFor(request => request.Outcode)
                .Matches("^([A-Za-z][0-9]{1,2})$")
                .WithMessage("Please provide a valid UK Outcode");
        }
    }
}
