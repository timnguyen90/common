using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace InterviewProxyApi.Controllers
{
    [ApiController]
    public class RestaurantsController : ControllerBase
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public RestaurantsController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [HttpGet("restaurants/bypostcode/{postcode}")]
        public async Task<IActionResult> GetByPostCode([FromRoute] string postcode)
        {
            var url = $"https://uk.api.just-eat.io/restaurants/bypostcode/{postcode}";
            var httpClient = _httpClientFactory.CreateClient();
            var response = await httpClient.GetStringAsync(url);
            var result = JsonConvert.DeserializeObject<SearchByPostcodeResponse>(response);
            result.Restaurants = result.Restaurants.Take(100).ToList();
            result.MetaData.ResultCount = result.Restaurants.Count;
            return Ok(result);
        }
    }
}
