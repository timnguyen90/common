namespace InterviewProxyApi
{
    using System;
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public class SearchByPostcodeResponse
    {
        [JsonProperty("Area")] public string Area { get; set; }

        [JsonProperty("MetaData")] public MetaData MetaData { get; set; }

        [JsonProperty("Restaurants")] public List<Restaurant> Restaurants { get; set; }

        [JsonProperty("ShortResultText")] public string ShortResultText { get; set; }
    }

    public class MetaData
    {
        [JsonProperty("CanonicalName")] public string CanonicalName { get; set; }

        [JsonProperty("District")] public string District { get; set; }

        [JsonProperty("Postcode")] public string Postcode { get; set; }

        [JsonProperty("Area")] public string Area { get; set; }

        [JsonProperty("Latitude")] public double Latitude { get; set; }

        [JsonProperty("Longitude")] public double Longitude { get; set; }

        //[JsonProperty("CuisineDetails")] public List<CuisineDetail> CuisineDetails { get; set; }

        [JsonProperty("ResultCount")] public long ResultCount { get; set; }

        [JsonProperty("DeliveryArea")] public string DeliveryArea { get; set; }
    }

    public class CuisineDetail
    {
        [JsonProperty("Name")] public string Name { get; set; }

        [JsonProperty("SeoName")] public string SeoName { get; set; }

        [JsonProperty("Total")] public long Total { get; set; }
    }

    public class Restaurant
    {
        [JsonProperty("Id")] public long Id { get; set; }

        [JsonProperty("Name")] public string Name { get; set; }

        [JsonProperty("UniqueName")] public string UniqueName { get; set; }

        [JsonProperty("Address")] public Address Address { get; set; }

        [JsonProperty("City")] public string City { get; set; }

        [JsonProperty("Postcode")] public string Postcode { get; set; }

        [JsonProperty("Latitude")] public long Latitude { get; set; }

        [JsonProperty("Longitude")] public long Longitude { get; set; }

        [JsonProperty("Rating")] public Rating Rating { get; set; }

        [JsonProperty("RatingStars")] public double RatingStars { get; set; }

        [JsonProperty("NumberOfRatings")] public long NumberOfRatings { get; set; }

        [JsonProperty("RatingAverage")] public double RatingAverage { get; set; }

        [JsonProperty("Description")] public string Description { get; set; }

        //[JsonProperty("Url")] public Uri Url { get; set; }

        //[JsonProperty("LogoUrl")] public Uri LogoUrl { get; set; }

        [JsonProperty("IsTestRestaurant")] public bool IsTestRestaurant { get; set; }

        [JsonProperty("IsHalal")] public bool IsHalal { get; set; }

        [JsonProperty("IsNew")] public bool IsNew { get; set; }

        [JsonProperty("ReasonWhyTemporarilyOffline")]
        public string ReasonWhyTemporarilyOffline { get; set; }

        [JsonProperty("DriveDistance")] public double DriveDistance { get; set; }

        [JsonProperty("DriveInfoCalculated")] public bool DriveInfoCalculated { get; set; }

        [JsonProperty("IsCloseBy")] public bool IsCloseBy { get; set; }

        [JsonProperty("OfferPercent")] public long OfferPercent { get; set; }

        [JsonProperty("NewnessDate")] public DateTimeOffset NewnessDate { get; set; }

        [JsonProperty("OpeningTime")] public DateTimeOffset? OpeningTime { get; set; }

        [JsonProperty("OpeningTimeUtc")] public object OpeningTimeUtc { get; set; }

        [JsonProperty("OpeningTimeIso")] public DateTimeOffset? OpeningTimeIso { get; set; }

        [JsonProperty("OpeningTimeLocal")] public DateTimeOffset? OpeningTimeLocal { get; set; }

        [JsonProperty("DeliveryOpeningTimeLocal")]
        public DateTimeOffset? DeliveryOpeningTimeLocal { get; set; }

        [JsonProperty("DeliveryOpeningTime")] public DateTimeOffset? DeliveryOpeningTime { get; set; }

        [JsonProperty("DeliveryOpeningTimeUtc")]
        public DateTimeOffset? DeliveryOpeningTimeUtc { get; set; }

        [JsonProperty("DeliveryStartTime")] public DateTimeOffset? DeliveryStartTime { get; set; }

        [JsonProperty("DeliveryTime")] public object DeliveryTime { get; set; }

        [JsonProperty("DeliveryTimeMinutes")] public object DeliveryTimeMinutes { get; set; }

        [JsonProperty("DeliveryWorkingTimeMinutes")]
        public long? DeliveryWorkingTimeMinutes { get; set; }

        [JsonProperty("DeliveryEtaMinutes")] public DeliveryEtaMinutes DeliveryEtaMinutes { get; set; }

        [JsonProperty("IsCollection")] public bool IsCollection { get; set; }

        [JsonProperty("IsDelivery")] public bool IsDelivery { get; set; }

        [JsonProperty("IsFreeDelivery")] public bool IsFreeDelivery { get; set; }

        [JsonProperty("IsOpenNowForCollection")]
        public bool IsOpenNowForCollection { get; set; }

        [JsonProperty("IsOpenNowForDelivery")] public bool IsOpenNowForDelivery { get; set; }

        [JsonProperty("IsOpenNowForPreorder")] public bool IsOpenNowForPreorder { get; set; }

        [JsonProperty("IsOpenNow")] public bool IsOpenNow { get; set; }

        [JsonProperty("IsTemporarilyOffline")] public bool IsTemporarilyOffline { get; set; }

        [JsonProperty("DeliveryMenuId")] public int? DeliveryMenuId { get; set; }

        [JsonProperty("CollectionMenuId")] public object CollectionMenuId { get; set; }

        [JsonProperty("DeliveryZipcode")] public object DeliveryZipcode { get; set; }

        [JsonProperty("DeliveryCost")] public long DeliveryCost { get; set; }

        [JsonProperty("MinimumDeliveryValue")] public long MinimumDeliveryValue { get; set; }

        [JsonProperty("SecondDateRanking")] public long SecondDateRanking { get; set; }

        [JsonProperty("DefaultDisplayRank")] public long DefaultDisplayRank { get; set; }

        [JsonProperty("SponsoredPosition")] public long SponsoredPosition { get; set; }

        [JsonProperty("SecondDateRank")] public long SecondDateRank { get; set; }

        [JsonProperty("Score")] public long Score { get; set; }

        [JsonProperty("IsTemporaryBoost")] public bool IsTemporaryBoost { get; set; }

        [JsonProperty("IsSponsored")] public bool IsSponsored { get; set; }

        [JsonProperty("IsPremier")] public bool IsPremier { get; set; }

        [JsonProperty("HygieneRating")] public object HygieneRating { get; set; }

        [JsonProperty("ShowSmiley")] public bool ShowSmiley { get; set; }

        [JsonProperty("SmileyDate")] public object SmileyDate { get; set; }

        [JsonProperty("SmileyElite")] public bool SmileyElite { get; set; }

        [JsonProperty("SmileyResult")] public object SmileyResult { get; set; }

        [JsonProperty("SmileyUrl")] public object SmileyUrl { get; set; }

        [JsonProperty("SendsOnItsWayNotifications")]
        public bool SendsOnItsWayNotifications { get; set; }

        [JsonProperty("BrandName")] public string BrandName { get; set; }

        [JsonProperty("IsBrand")] public bool IsBrand { get; set; }

        [JsonProperty("LastUpdated")] public DateTimeOffset? LastUpdated { get; set; }

        [JsonProperty("Deals")] public List<object> Deals { get; set; }

        [JsonProperty("Offers")] public List<object> Offers { get; set; }

        [JsonProperty("Logo")] public List<Logo> Logo { get; set; }

        [JsonProperty("Tags")] public List<object> Tags { get; set; }

        [JsonProperty("DeliveryChargeBands")] public List<object> DeliveryChargeBands { get; set; }

        [JsonProperty("CuisineTypes")] public List<CuisineType> CuisineTypes { get; set; }

        [JsonProperty("Cuisines")] public List<Cuisine> Cuisines { get; set; }

        [JsonProperty("ScoreMetaData")] public List<ScoreMetaDatum> ScoreMetaData { get; set; }

        [JsonProperty("Badges")] public List<object> Badges { get; set; }

        [JsonProperty("OpeningTimes")] public List<object> OpeningTimes { get; set; }

        [JsonProperty("ServiceableAreas")] public List<object> ServiceableAreas { get; set; }
    }

    public class Address
    {
        [JsonProperty("City")] public string City { get; set; }

        [JsonProperty("FirstLine")] public string FirstLine { get; set; }

        [JsonProperty("Postcode")] public string Postcode { get; set; }

        [JsonProperty("Latitude")] public double Latitude { get; set; }

        [JsonProperty("Longitude")] public double Longitude { get; set; }
    }

    public class CuisineType
    {
        [JsonProperty("Id")] public long Id { get; set; }

        [JsonProperty("IsTopCuisine")] public bool IsTopCuisine { get; set; }

        [JsonProperty("Name")] public string Name { get; set; }

        [JsonProperty("SeoName")] public string SeoName { get; set; }
    }

    public class Cuisine
    {
        [JsonProperty("Name")] public string Name { get; set; }

        [JsonProperty("SeoName")] public string SeoName { get; set; }
    }

    public class DeliveryEtaMinutes
    {
        [JsonProperty("Approximate")] public object Approximate { get; set; }

        [JsonProperty("RangeLower")] public long RangeLower { get; set; }

        [JsonProperty("RangeUpper")] public long RangeUpper { get; set; }
    }

    public class Logo
    {
        [JsonProperty("StandardResolutionURL")]
        public Uri StandardResolutionUrl { get; set; }
    }

    public class Rating
    {
        [JsonProperty("Count")] public long Count { get; set; }

        [JsonProperty("Average")] public double Average { get; set; }

        [JsonProperty("StarRating")] public double StarRating { get; set; }
    }

    public class ScoreMetaDatum
    {
        [JsonProperty("Key")] public string Key { get; set; }

        [JsonProperty("Value")] public string Value { get; set; }
    }
}
