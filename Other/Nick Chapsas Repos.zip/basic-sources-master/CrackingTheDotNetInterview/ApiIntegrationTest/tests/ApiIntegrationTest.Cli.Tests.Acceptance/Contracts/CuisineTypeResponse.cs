using System.Text.Json.Serialization;

namespace ApiIntegrationTest.Cli.Tests.Acceptance.Contracts
{
    public class CuisineTypeResponse
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
    }
}
