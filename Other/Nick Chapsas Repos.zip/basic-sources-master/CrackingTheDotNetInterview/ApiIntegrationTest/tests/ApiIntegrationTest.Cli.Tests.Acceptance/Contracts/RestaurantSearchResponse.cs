using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace ApiIntegrationTest.Cli.Tests.Acceptance.Contracts
{
    public class RestaurantSearchResponse
    {
        [JsonPropertyName("restaurants")]
        public IReadOnlyList<RestaurantResponse> Restaurants { get; init; }
    }
}
