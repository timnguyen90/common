using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ApiIntegrationTest.Cli.Tests.Acceptance.Models;
using BoDi;
using TechTalk.SpecFlow;
using WireMock.Server;

namespace ApiIntegrationTest.Cli.Tests.Acceptance.Hooks
{
    [Binding]
    public class SearchForRestaurantsByOutcodeHooks
    {
        private readonly string SolutionRootFolder = "ApiIntegrationTest";
        private const string CliDirectoryName = "ApiIntegrationTest.Cli";
        private static readonly string CliDllName = $"ApiIntegrationTest.Cli.dll";
        private WireMockServer _wireMockServer;
        private readonly ProjectPaths _projectPaths = new();
        private readonly IObjectContainer _objectContainer;

        public SearchForRestaurantsByOutcodeHooks(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
        }

        [BeforeScenario]
        public async Task SetupApiMock()
        {
            SetupFileLocations();
            await BuildProject();
            _wireMockServer = WireMockServer.Start();
            _objectContainer.RegisterInstanceAs(_wireMockServer);
            _objectContainer.RegisterInstanceAs(_projectPaths);
        }

        [AfterScenario]
        public void TeardownApiMock()
        {
            _wireMockServer.Stop();
        }

        private async Task BuildProject()
        {
            var buildCommand =
                @$"build {Path.Combine(_projectPaths.SolutionRootFolderPath, _projectPaths.PathToBuild)}";
            var process = ProcessHelpers.CreateDotnetCommandProcess(buildCommand);
            process.Start();
            await process.WaitForExitAsync();
        }

        private void SetupFileLocations()
        {
            _projectPaths.SolutionRootFolderPath = GetSolutionRootFolderPath();
            _projectPaths.PathToBuild = Directory.EnumerateDirectories(_projectPaths.SolutionRootFolderPath, "*", SearchOption.AllDirectories)
                .SingleOrDefault(x => x.EndsWith(CliDirectoryName));
            _projectPaths.PathToExecute = Directory
                .EnumerateFiles(_projectPaths.SolutionRootFolderPath, "*.dll", SearchOption.AllDirectories)
                .FirstOrDefault(x => x.Contains(BuildDirectorySafeguard())
                                     && !x.Contains($"{Path.DirectorySeparatorChar}ref") && x.EndsWith(CliDllName));

            string BuildDirectorySafeguard() =>
                $@"{CliDirectoryName}{Path.DirectorySeparatorChar}bin{Path.DirectorySeparatorChar}Debug";
        }

        private string GetSolutionRootFolderPath()
        {
            var test = Directory.GetCurrentDirectory();

            while (!test.EndsWith(SolutionRootFolder))
            {
                test = test.Substring(0, test.LastIndexOf(Path.DirectorySeparatorChar));
            }

            return test;
        }
    }
}
