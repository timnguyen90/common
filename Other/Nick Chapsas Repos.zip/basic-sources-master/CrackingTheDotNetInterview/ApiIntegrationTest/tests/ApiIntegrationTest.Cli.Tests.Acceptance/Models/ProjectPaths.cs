namespace ApiIntegrationTest.Cli.Tests.Acceptance.Models
{
    public class ProjectPaths
    {
        public string PathToBuild { get; set; }

        public string PathToExecute { get; set; }

        public string SolutionRootFolderPath { get; set; }
    }
}
