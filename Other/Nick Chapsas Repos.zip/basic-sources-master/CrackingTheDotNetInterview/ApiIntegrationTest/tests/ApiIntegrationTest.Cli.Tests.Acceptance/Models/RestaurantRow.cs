namespace ApiIntegrationTest.Cli.Tests.Acceptance.Models
{
    public class RestaurantRow
    {
        public string Name { get; set; }

        public double Rating { get; set; }

        public string CuisineType { get; set; }
    }
}
