using System.Collections.Generic;

namespace ApiIntegrationTest.Cli.Tests.Acceptance.Models
{
    public class RestaurantSearchResult
    {
        public IReadOnlyList<RestaurantResult> Restaurants { get; init; }
    }
}
