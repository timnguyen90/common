using System.Collections.Generic;
using System.Diagnostics;

namespace ApiIntegrationTest.Cli.Tests.Acceptance
{
    public class ProcessHelpers
    {
        public static Process CreateDotnetCommandProcess(string arguments, IDictionary<string, string> environmentVariables = null)
        {
            var process = new Process()
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = @"dotnet",
                    Arguments = arguments,
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };

            if (environmentVariables is not null)
            {
                foreach (var (key, value) in environmentVariables)
                {
                    process.StartInfo.Environment[key] = value;
                }
            }

            return process;
        }
    }
}
