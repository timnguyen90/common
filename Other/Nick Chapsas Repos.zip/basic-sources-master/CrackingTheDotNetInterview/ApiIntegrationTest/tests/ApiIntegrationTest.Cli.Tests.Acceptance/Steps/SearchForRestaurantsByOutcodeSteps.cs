using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using ApiIntegrationTest.Cli.Tests.Acceptance.Contracts;
using ApiIntegrationTest.Cli.Tests.Acceptance.Models;
using BoDi;
using FluentAssertions;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using WireMock.RequestBuilders;
using WireMock.ResponseBuilders;
using WireMock.Server;

namespace ApiIntegrationTest.Cli.Tests.Acceptance.Steps
{
    [Binding]
    public class SearchForRestaurantsByOutcodeSteps
    {
        private string _outcode;
        private List<RestaurantRow> _setupRestaurants;
        private Process _cliSearchProcess;

        private readonly IObjectContainer _objectContainer;

        public SearchForRestaurantsByOutcodeSteps(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
        }

        [Given(@"the outcode (.*)")]
        public void GivenTheOutcodeE2(string outcode)
        {
            _outcode = outcode;
        }

        [Given(@"the following restaurants that are delivering there")]
        public void GivenTheFollowingRestaurantsThatAreDeliveringThere(Table table)
        {
            var restaurants = table.CreateSet<RestaurantRow>();
            _setupRestaurants = restaurants.ToList();
            var searchApiResponse = new RestaurantSearchResponse
            {
                Restaurants = _setupRestaurants.Select(x => new RestaurantResponse
                {
                    Name = x.Name,
                    Rating = x.Rating,
                    CuisineTypes = new []{new CuisineTypeResponse{Name = x.CuisineType}}
                }).ToList()
            };

            var wireMockServer = _objectContainer.Resolve<WireMockServer>();
            wireMockServer.Given(Request.Create().WithPath($"/restaurants/bypostcode/{_outcode}").UsingGet())
            .RespondWith(Response.Create()
                .WithStatusCode(200)
                .WithBody(JsonSerializer.Serialize(searchApiResponse)));
        }

        [When(@"a user searches for restaurants at that outcode")]
        public void WhenAUserSearchesForRestaurantsAtTheOutcodeE2()
        {
            var wireMockServer = _objectContainer.Resolve<WireMockServer>();
            var projectPaths = _objectContainer.Resolve<ProjectPaths>();

            var arguments = $"--o {_outcode}";
            var envVariables = new Dictionary<string, string>
            {
                {"CLI_RestaurantApi__BaseAddress", wireMockServer.Urls[0]}
            };

            _cliSearchProcess = ProcessHelpers.CreateDotnetCommandProcess(@$"{Path.Combine(projectPaths.SolutionRootFolderPath, projectPaths.PathToExecute)} {arguments}", envVariables);
            _cliSearchProcess.Start();
        }

        [Then(@"the restaurants are returned")]
        public async Task ThenTheRestaurantsAreReturned()
        {
            var expectedResult = new RestaurantSearchResult
            {
                Restaurants = _setupRestaurants.Select(x => new RestaurantResult()
                {
                    Name = x.Name,
                    Rating = x.Rating,
                    CuisineTypes = new []{ x.CuisineType }
                }).ToList()
            };

            var resultAsText = await _cliSearchProcess.StandardOutput.ReadToEndAsync();
            await _cliSearchProcess.WaitForExitAsync();

            var result = JsonSerializer.Deserialize<RestaurantSearchResult>(resultAsText);

            result!.Should().BeEquivalentTo(expectedResult,
                options => options
                    .ComparingByMembers<RestaurantSearchResult>()
                    .ComparingByMembers<RestaurantResult>());
        }

        [Then("the error \"(.+)\" is returned")]
        public async Task ThenTheErrorPleaseProvideAValidUkOutcodeIsReturned(string errorMessage)
        {
            var resultAsText = (await _cliSearchProcess.StandardOutput.ReadToEndAsync()).TrimEnd();
            await _cliSearchProcess.WaitForExitAsync();
            resultAsText.Should().Be(errorMessage);
        }
    }
}
