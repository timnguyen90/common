using System.Text.Json;
using System.Threading.Tasks;
using ApiIntegrationTest.Cli.Models;
using ApiIntegrationTest.Cli.Output;
using ApiIntegrationTest.Cli.Services;
using AutoFixture;
using NSubstitute;
using OneOf;
using Xunit;

namespace ApiIntegrationTest.Cli.Tests.Unit
{
    public class RestaurantSearchApplicationTests
    {
        private readonly RestaurantSearchApplication _sut;
        private readonly IConsoleWriter _consoleWriter = Substitute.For<IConsoleWriter>();
        private readonly IRestaurantSearchService _restaurantSearchService = Substitute.For<IRestaurantSearchService>();
        private readonly IFixture _fixture = new Fixture();

        public RestaurantSearchApplicationTests()
        {
            _sut = new RestaurantSearchApplication(_consoleWriter, _restaurantSearchService);
        }

        [Fact]
        public async Task RunAsync_ShouldReturnRestaurants_WhenOutcodeIsValid()
        {
            // Arrange
            const string outcode = "E2";
            var arguments = new []{"--o", outcode};

            var restaurantResult = _fixture.Create<RestaurantSearchResult>();
            OneOf<RestaurantSearchResult, RestaurantSearchError> result = restaurantResult;

            var searchResult = new RestaurantSearchRequest(outcode);
            _restaurantSearchService.SearchByOutcodeAsync(searchResult).Returns(result);

            var expectedSerializedText = JsonSerializer.Serialize(restaurantResult, new JsonSerializerOptions
            {
                WriteIndented = true
            });

            // Act
            await _sut.RunAsync(arguments);

            // Assert
            _consoleWriter.Received(1).WriteLine(Arg.Is(expectedSerializedText));
        }

        [Fact]
        public async Task RunAsync_ShouldReturnErrorMessage_WhenOutcodeIsInvalid()
        {
            // Arrange
            const string outcode = "E2 1AA";
            var arguments = new []{"--o", outcode};
            const string invalidOutcodeError = "Please provide a valid UK Outcode";

            var errorResult = new RestaurantSearchError(new[] {invalidOutcodeError});
            OneOf<RestaurantSearchResult, RestaurantSearchError> result = errorResult;

            var searchResult = new RestaurantSearchRequest(outcode);
            _restaurantSearchService.SearchByOutcodeAsync(searchResult).Returns(result);

            // Act
            await _sut.RunAsync(arguments);

            // Assert
            _consoleWriter.Received(1).WriteLine(Arg.Is(invalidOutcodeError));
        }
    }
}
