using System.Linq;
using System.Threading.Tasks;
using ApiIntegrationTest.Cli.Api;
using ApiIntegrationTest.Cli.Api.Responses;
using ApiIntegrationTest.Cli.Mapping;
using ApiIntegrationTest.Cli.Models;
using ApiIntegrationTest.Cli.Services;
using ApiIntegrationTest.Cli.Validators;
using AutoFixture;
using FluentAssertions;
using FluentValidation;
using NSubstitute;
using Xunit;

namespace ApiIntegrationTest.Cli.Tests.Unit
{
    public class RestaurantSearchServiceTests
    {
        private readonly RestaurantSearchService _sut;
        private readonly IRestaurantApi _restaurantApi = Substitute.For<IRestaurantApi>();
        private readonly IValidator<RestaurantSearchRequest> _validator = new RestaurantSearchRequestValidator();
        private readonly IFixture _fixture = new Fixture();

        public RestaurantSearchServiceTests()
        {
            _sut = new RestaurantSearchService(_restaurantApi, _validator);
        }

        [Fact]
        public async Task SearchByOutcodeAsync_ShouldReturnResults_WhenOutcodeIsValid()
        {
            // Arrange
            const string outcode = "E2";
            var request = new RestaurantSearchRequest(outcode);
            var apiResponse = _fixture.Create<RestaurantSearchResponse>();
            _restaurantApi.SearchByPostcodeAsync(outcode).Returns(apiResponse);
            var expectedResult = new RestaurantSearchResult
            {
                Restaurants = apiResponse.Restaurants.Select(x => x.ToRestaurantResult()).ToList()
            };

            // Act
            var result = await _sut.SearchByOutcodeAsync(request);

            // Assert
            result.AsT0.Should().BeEquivalentTo(expectedResult, options =>
                options.ComparingByMembers<RestaurantSearchResult>()
                    .ComparingByMembers<RestaurantResult>());
        }

        [Fact]
        public async Task SearchByOutcodeAsync_ShouldReturnError_WhenOutcodeIsInvalid()
        {
            // Arrange
            const string outcode = "E21AA";
            var request = new RestaurantSearchRequest(outcode);
            var errorMessages = new[] { "Please provide a valid UK Outcode" };
            var expectedResult = new RestaurantSearchError(errorMessages);

            // Act
            var result = await _sut.SearchByOutcodeAsync(request);

            // Assert
            result.AsT1.Should().BeEquivalentTo(expectedResult,
                options => options.ComparingByMembers<RestaurantSearchError>());
        }
    }
}
