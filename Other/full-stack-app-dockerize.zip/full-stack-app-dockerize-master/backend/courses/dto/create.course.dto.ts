import { CourseDto } from './course.dto';
export interface CreateCourseDto extends CourseDto {}