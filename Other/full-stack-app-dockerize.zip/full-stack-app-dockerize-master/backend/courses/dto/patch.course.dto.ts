import { PutCourseDto } from './put.course.dto';

export interface PatchCourseDto extends Partial<PutCourseDto> {}