import { CourseDto } from './course.dto';
export interface PutCourseDto extends CourseDto {}