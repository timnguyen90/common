export const environment = {
  production: true,
  apiUrl: "http://167.71.89.22:3000/api",
};
